const path = require("path");

const product = {
  product: (req, res) => {
    res.render("product")
  },
};
module.exports = product;

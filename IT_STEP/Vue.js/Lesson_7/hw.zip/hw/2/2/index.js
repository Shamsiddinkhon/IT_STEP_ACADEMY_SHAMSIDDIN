let fs= require('fs')

// let date = new Date();
// fs.writeFile("data.txt", date.toLocaleString(), function(err){
//     if (err) throw err;
// })


// fs.readFile("data.txt", 'utf8', function(err, data){
//     if(err) throw err
//     console.log(data);
// })




var app = angular.module('app', ['ngRoute']);

app.config(function ($routeProvider, $locationProvider) {

   $routeProvider
       .when('/', {
           templateUrl: '<h1>Posts my first site</h1>'
           controller: 'homeController'
       })
       .when('posts', {
           template: '<h1>Posts my first site</h1>'
       });

    $locationProvider.html5Mode(true);

});

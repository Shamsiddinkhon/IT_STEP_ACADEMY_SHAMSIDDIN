'use strict';

angular.module('shopApp', [
    'ngRoute',
    'shopControllers',
    'shopDirectives'
]).
    config(['$routeProvider',
        function($routeProvider){
            $routeProvider.
                when('/home',{
                    templateUrl:'templates/home.html',
                    controller: 'ShopHomeCtrl',
                    controllerAs: 'home'
                }).
                when('/pc',{
                    templateUrl:'templates/pc.html',
                    controller: 'ShopPcCtrl'
                }).
                when('/pc/:pcId', {
                    templateUrl:'templates/detail.html',
                    controller: 'ShopPcDetailCtrl'
                }).
                otherwise({
                    redirectTo: '/home'
                });
        }
    ]);
'use strict'

angular.module('shopDirectives', [])

.directive('shopHeader', function(){
    return{
        restrict: 'E',
        templateUrl: 'templates/header.html',
        controller: function(){
            this.logo = 'Shop'
        },
        controllerAs: 'header'
    }
})
.directive('shopWelcome', function(){
    return{
        restrict: 'E',
        templateUrl: 'templates/welcome.html'
    }
});
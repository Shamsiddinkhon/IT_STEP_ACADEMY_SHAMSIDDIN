'use strict'

var shopControllers = angular.module('shopControllers', []);

shopControllers.controller('ShopHomeCtrl', [
    function(){
        this.data = 'lorem';
    }
]);

shopControllers.controller('ShopPcCtrl', ['$http', '$scope',
    function($http, $scope){

        $http.get('data/pc/pc.json').success(function(data){
            $scope.data = data;
        });
    }
]);

shopControllers.controller('ShopPcDetailCtrl', ['$scope', '$http', '$routeParams',
    function($scope, $http, $routeParams){
        $http.get('data/pc/pc.json').success(function(data){
            $scope.data = data[$routeParams.pcId - 1];
        });
    }
]);
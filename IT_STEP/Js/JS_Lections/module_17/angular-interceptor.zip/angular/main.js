var app = angular.module('app', ['ngRoute']);



app.config(function ($routeProvider, $httpProvider) {


    $httpProvider.interceptors.push(function ($q) {
        return {

            // optional method
            request: function (config) {
                // do something on success
                config.headers['Authorization'] = 'root';

                return config;
            },

            // optional method
            requestError: function (rejection) {
                // do something on error
                if (canRecover(rejection)) {
                    return responseOrNewPromise
                }
                return $q.reject(rejection);
            },


            // optional method
            response: function (response) {
                // do something on success
                return response;
            },

            // optional method
            responseError: function (rejection) {
                // do something on error
                if (canRecover(rejection)) {
                    return responseOrNewPromise
                }
                return $q.reject(rejection);
            }
        }

    })

});
app.controller('MyController', function ($http) {

    $http.get('http://localhost:3001/books').then(function (response) {
        console.log(response);
    }, function () {

    });

});

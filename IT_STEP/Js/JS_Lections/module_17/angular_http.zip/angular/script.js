var app = angular.module('app', []);

app.controller('MyController', function ($scope, $http) {

    $http.get('http://localhost:3001/books').then(function (response) {
        $scope.books = response.data;
    }, function (err) {
        console.log(err);
    });

    $scope.addBook = function (book) {
        $http.post('http://localhost:3001/books', book).then(function (response) {
            console.log('Books success');
            $scope.books.push(book);
            $scope.book = null;
        }, function (err) {

        });
    }

});
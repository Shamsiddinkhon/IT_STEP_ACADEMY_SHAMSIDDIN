//alert("asdfsadfasd");
// var a = prompt("a = ");
// var b = prompt("b = ");
// var c = +a + +b;
// console.log(c);
// var agreed = confirm("Вы согласны?");
// console.log(agreed);
// var str = "string";
// console.log(str.length);

// var cat = {
//     name: "Барсик",
//     meow: function(){
//         console.log("MEOW");
//     }
// }

// console.log( cat.name );
// cat.meow();

// var arr = [5, 2, 3, 0];
// // arr.push(1);
// // arr.unshift(5)
// arr.pop();
// arr.shift();
// console.log( arr );

//var n = "Привет!";
//alert(n.length);
//console.log( n.substring(2, 5) );
//console.log( n[3] );
//var randomNumber = Math.random();//от 0 до 1  [0, 1)
// var randomNumber = Math.floor ( Math.random() * 10 + 5 );
// console.log(randomNumber);

// var date = new Date();

//console.log( date.toLocaleString() );
// console.log( date.getMilliseconds() );
// console.log( date.getSeconds() );
// console.log( date.getMinutes() );
// console.log( date.getHours() );
// console.log( date.getDate() );
// console.log( date.getMonth() );
// console.log( date.getFullYear() );
// console.log( date.getDay() );

// date.setMilliseconds(111);
// date.setSeconds(59);
// date.setMinutes(22);
// date.setHours(26);
// date.setDate(9);
// date.setMonth(0);
// date.setFullYear(2010);
//console.log( date.getDay() );

//var date = new Date(60000);
//var date = new Date(2019, 9, 5, 15, 15, 35, 999);
// var date = new Date(2019, 9);
// console.log( date.toLocaleString() );

// function sayHello(){
//     alert("Hello!");
// }

// setTimeout(sayHello, 5000);

// var i = 0;
// function count(){
//     i++;
//     console.log(i);
// }

// setInterval(count, 1000);
var i = 5, j = 6;
console.log( i + ":" + j )
console.clear();